import java.util.Scanner;
class Weeks{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
System.out.println("Enter the week number:");
int day=s.nextInt();
switch(day){
case 1:
System.out.println(day+"is monday");
break;
case 2:
System.out.println(day+"is tuesday");
break;
case 3:
System.out.println(day+" is wednesday");
break;
case 4:
System.out.println(day+" is Thursday");
break;
case 5:
System.out.println(day+"is friday");
break;
case 6:
System.out.println(day+"is saturday");
break;
case 7:
System.out.println(day+"is sunday");
    break;
}
}
}