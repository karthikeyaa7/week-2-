class Example4
  {
  public static void main(String args[]) {
    int a = 100;
    int b = 50;
    int sum = a + b;
    int sub = a - b;
    int multi = a * b;
    int div = a / b;
    System.out.println("Sum is :" + sum);
    System.out.println("Subtraction is :" + sub);
    System.out.println("Multiplication is :" + multi);
    System.out.println("Division is :" + div);
  }
}