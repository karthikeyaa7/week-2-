import java.util.Scanner;
class Example3
{
  public static void main(String[] args){
    Scanner ip=new Scanner(System.in);
    System.out.println("Enter the bs");
    int Basic=ip.nextInt();
    System.out.println("Enter bill1");
    int bill1=ip.nextInt();
    System.out.println("Enter bill2");
    int bill2=ip.nextInt();
    System.out.println("Enter bill3");
    int bill3=ip.nextInt();
    int w=bill1+bill2+bill3;
    System.out.println("Total Shopping amount "+(bill1+bill2+bill3));
    System.out.println("Total amount spent for shopping  "+((Basic*w)/100));
    
  } 
}