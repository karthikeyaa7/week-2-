import java.util.Scanner;
class Example5
  {
  public static void main(String[] args) {
    Scanner ip = new Scanner(System.in);
    System.out.println("enter sub1");
    int a = ip.nextInt();
    System.out.println("enter Sub2");
    int b = ip.nextInt();
    System.out.println("enter sub3");
    int c = ip.nextInt();
    System.out.println("Sum of subjects " + (a + b + c));
    System.out.println("Avg of subjects " + (a + b + c / 3));
  }
}