import java.util.Scanner;

class Example8{
  public static void main(String args[]){
    Scanner s = new Scanner(System.in);
    int num=0;
    System.out.println("enter the age");
    num = s.nextInt();
    if (num>=18){
     System.out.println(num+"eligible to vote");
    } else{
      System.out.println(num+"not elgible to vote");
      
    }
    }
  }
