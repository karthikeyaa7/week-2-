import java.util.Scanner;
public class Bistro {
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
System.out.println("Enter items ");
int item=s.nextInt();
System.out.println("item");
String ch=s.next();
System.out.println("grouping ");
String sh=s.next();
switch(item)
{
case 1: 
    System.out.println("Vegetarian food");
switch(ch)
{
case "paneer":
System.out.println("Items are paneer manchuri, tikka and pizza");
break;
case "veggies":
System.out.println("Items are tikki, pulao and curry");
break;
}
switch(sh)
{
case "cold":
System.out.println("items are icecream, milkshake");
break;
case "hot":
System.out.println("items are gulab jamun and rasgulla");
break;
}
case 2: System.out.println("Nonvegetarian food");
switch(ch)
  {
case "chicken":
System.out.println("Items are chicken manchuri, tikka and pizza");
break;
case "egg":
System.out.println("Items are omlete.friedrice and curry");
    break;
}
}
}
}