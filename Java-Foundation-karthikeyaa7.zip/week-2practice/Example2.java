class Example2 {
 
  public static void main(String args[]) {
 
    int num1 = 90, num2 = 34, sum = 0;
    sum = num1 + num2;
    System.out.println("Addition is : " + sum);
  }
 
}