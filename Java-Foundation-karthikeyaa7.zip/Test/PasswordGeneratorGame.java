import java.util.*;

class PasswordGeneratorGame {
  public static void main(String a[]) {
    System.out.println("enter password length");
    Scanner s = new Scanner(System.in);
    int size = s.nextInt();
    GeneratePassword(size);
  }

  static void GeneratePassword(int len) {
    String password = "";
    int i = 1;
    while (i <= len) {
      int ran = (int) (Math.random() * 62);
      // 0-9, 'A-Z','a-z' total 62
      System.out.println(ran);
      if (ran >= 0 && ran <= 9) {
        ran = ran + 48;
        // 0-9 ASCII  48-57
        password = password + (char) ran;
      } else if (ran >= 10 && ran <= 35) {
        ran = ran + 55;
        //10-35 ASCII  65-90.
        password = password + (char) ran;

      } else {
        ran = ran + 61;
        password = password + (char) ran;
      // 36-61 ASCII 97-122
      }
      i = i + 1;
    }
    System.out.println(password);

    Validate(password);
    
  }
  void Validate(String p)
  {
    int count=0;
    for(int i=0;i<p.length();i++)
      {
        if(p.charAt(i)>='0'&&p.charAt(i)<='9')
        {
          count=count+1;
          break;
        }
      }
    for(int i=0;i<p.length();i++)
      {
        if(p.charAt(i)>='A'&&p.charAt(i)<='Z')
        {
          count=count+1;
          break;
        }
      }
    for(int i=0;i<p.length();i++)
      {
        if(p.charAt(i)>='a'&&p.charAt(i)<='z')
        {
          count=count+1;
          break;
        }
      }
    if(count==3)
      System.out.println("valid");
    else
      System.out.println("in valid ");
  }
}