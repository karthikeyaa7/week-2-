import java.util.*;

class StringExample {
  public static void main(String ar[]) {
    String string = new String();
    Scanner scanner = new Scanner(System.in);
    System.out.println("Read some data");
    string = scanner.nextLine();
    StringBuffer s=new StringBuffer(string);
    System.out.println(s);
  }
    }
    