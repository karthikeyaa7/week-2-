// storing and reading data from an array dynamically
import java.util.*;
class ArrayExample
{
  public static void main(String w[])
  {
    Scanner t=new Scanner(System.in);
    System.out.println("enter number of elements in an array");
    int size;
    size=t.nextInt();  
    // size holding array size
     int amount[]=new int[size]; 
    // allocating memory for array

    System.out.println("enter array elements");
    for(int p=0;p<=size-1;p++)  
      // for travelling over indexes
      amount[p]=t.nextInt();
    // for reading array elements from i/p keyword
    // how to give data dynamically
    displayArrayElements(amount,size);
      
  }
 static void  displayArrayElements(int a[],int s)
  {
     
    for(int h:a)  // element of array
      System.out.println(h);
   // printting arrayu elements
    System.out.println(a[s]);

  }
}