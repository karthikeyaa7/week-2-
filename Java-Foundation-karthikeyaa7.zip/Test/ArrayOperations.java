import java.util.*;
class ArrayOperations
  {
    public static void main(String ar[])
    {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter no of elements in an array");
      int size=s.nextInt();
      int array[]=new int[size];
      System.out.println("Array Operations are");
      System.out.println(" 1. Insert an element in first index");  
 System.out.println("2. Insert an element in last index");
 System.out.println("3. Insert an element in specified index");
System.out.println("4.  Remove element from first index");
 System.out.println("5. Remove element from last index");
System.out.println("6. Remove element from specified index");
 System.out.println("7. Remove user eneted element");
System.out.println("8. Display all in ASC/DESC order.");
   System.out.println("9. Display array elements.");   
      System.out.println("Which of the  operation you you want to perform on array");
      int option=s.nextInt();
      switch(option)
        {
          case 1: insertAtFisrtIndex(array,size);
                  break;
          case 2: insertAtLastIndex(array,size);
                  break;
          case 3: insertAtSpecifiedIndex(array,size);
                  break;
          case 4: removeFromFisrtIndex(array,size);
                  break;
          case 5: removeFromLastIndex(array,size);
                  break;
          case 6: removeFromSpecifiedIndex(array,size);
                  break;
          case 7: removeUserElement(array,size);
                  break;
          case 8: DisplayInAscendingOrder(array,size);
                  break;
          case 9: DisplayArrayelements(array,size);
                  break;  
        }
    }
    static void insertAtFisrtIndex(int arr[],int size)
    {
    System.out.println("enter element to insert at first index");
      Scanner s=new Scanner(System.in);
      arr[0]=s.nextInt();
      
    }
    static void insertAtLastIndex(int arr[],int size)
    {
      
    }
   static  void insertAtSpecifiedIndex(int arr[],int size)
    {
       Scanner s=new Scanner(System.in);
      System.out.println("Enter postion no to insert data");
      int position=s.nextInt();
      
      System.out.println("enter element to insert at"+position+"index");     
      arr[position]=s.nextInt();
    }
   static  void removeFromFisrtIndex(int arr[],int size)
    {
      arr[0]=0;
    }
    static void removeFromLastIndex(int arr[],int size)
    {
      
    }
   static  void removeFromSpecifiedIndex(int arr[],int size)
    {
      
    }
   static  void removeUserElement(int arr[],int size)
    {
       Scanner s=new Scanner(System.in);
      System.out.println("enter element to remove from array");
      int remove=s.nextInt();
      int i;
      for( i=0;i<size;i++)
        {
        if(arr[i]==remove)
          arr[i]=0;
          //break;
        }
      if(i==size)
        System.out.println(remove+"not available in the array");
      
    }
    static void DisplayInAscendingOrder(int arr[],int size)
    {
      
    }
  static void   DisplayArrayelements(int arr[],int size)
    {
      
    }
  }